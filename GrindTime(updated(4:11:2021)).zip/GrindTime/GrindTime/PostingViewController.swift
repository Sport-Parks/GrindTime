//
//  PostingViewController.swift
//  GrindTime
//
//  Created by user191262 on 4/11/21.
//

import UIKit
import Parse
import AlamofireImage

    class PostingViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    @IBOutlet weak var tableView: UITableView!
        
        var usercomments = [PFObject]()
        
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
    }
        
        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            
            let query = PFQuery(className:"UserComments")
            query.includeKey("Writer")
            query.limit = 20
            
            query.findObjectsInBackground { (usercomments, error) in
                if usercomments != nil {
                    self.usercomments = usercomments!
                    self.tableView.reloadData()
                }
                
            }        }
           
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return usercomments.count
            
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "PostViewCell") as! PostViewCell
            let Mycomments = usercomments[indexPath.row]
            let name = Mycomments["Writer"] as! PFUser
            cell.nameLabel.text = name.username
            
            cell.commentLabel.text = Mycomments["Comments"] as! String
            
            let imageFile = Mycomments["Pic"] as! PFFileObject
            let urlString = imageFile.url!
            let url = URL(string: urlString)!
            
            cell.pictureView.af_setImage(withURL: url)
            
            return cell
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

        @IBAction func backbutton(_ sender: Any) {
            dismiss(animated: true, completion: nil)        }
    }
