//
//  MessageViewController.swift
//  GrindTime
//
//  Created by GrindTime team
//

import UIKit
import Parse
import AlamofireImage
import MessageInputBar

class MessageViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    @IBOutlet weak var tableView: UITableView!
    
    var Mymessages = [PFObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let query = PFQuery(className:"Messages")
        query.includeKey("Writer")
        query.limit = 50
        
        
        query.findObjectsInBackground { (Mymessages, error) in
            if Mymessages != nil {
                self.Mymessages = Mymessages!
                self.tableView.reloadData()
            }
        }
    }


func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    let message = Mymessages[section]
    let replies = (message["TheReplys"] as? [PFObject]) ?? []
    
    return replies.count + 1
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return Mymessages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let message = Mymessages[indexPath.section]
        let replies = (message["TheReplys"] as? [PFObject]) ?? []
        
        if indexPath.row == 0 {
         let cell = tableView.dequeueReusableCell(withIdentifier: "MessageViewCell") as! MessageViewCell
      
          let name = message["Writer"] as! PFUser
          cell.nameText.text = name.username
        
          cell.messageText.text = message["TheMessages"] as! String
        
          let FileImage = message["ProfileImage"] as! PFFileObject
          let urlString = FileImage.url!
          let url = URL(string: urlString)!
        
          cell.messageimageView.af_setImage(withURL: url)
        
          return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ReplyViewCell") as! ReplyViewCell
            let reply = replies[indexPath.row - 1]
            cell.replyText.text = reply["TheReplys"] as? String
            
            let names = reply["Writer"] as! PFUser
            cell.replynameText.text = names.username
            
            let FileImage = message["ProfileImage"] as! PFFileObject
            let urlString = FileImage.url!
            let url = URL(string: urlString)!
          
            cell.replyimageView.af_setImage(withURL: url)
            
            return cell
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func BackButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
