//
//  ReplysViewController.swift
//  GrindTime
//
//  
//

import UIKit
import Parse
import AlamofireImage

class ReplysViewController: UIViewController{

    
    @IBOutlet weak var textreplyView: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func sendReplyButton(_ sender: Any) {
        let reply = PFObject(className: "replys")
            
            reply["thereply"] = textreplyView.text!
            reply["user"] = PFUser.current()!
            
            reply.saveInBackground { (success, error) in
                if success {
                    self.dismiss(animated: true, completion: nil)
                    print("Saved!")
                } else {
                    print("There is an error! Try again!")
                }
            }    }
}
