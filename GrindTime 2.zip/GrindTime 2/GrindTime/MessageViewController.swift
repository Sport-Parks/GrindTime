//
//  MessageViewController.swift
//  GrindTime
//
//  Created by GrindTime team
//

import UIKit
import Parse
import AlamofireImage
import MessageInputBar

class MessageViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var Mymessages = [PFObject]()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let query = PFQuery(className:"Messages")
        query.includeKey("Writer")
        query.limit = 50
        
        query.findObjectsInBackground { (Mymessages, error) in
            if Mymessages != nil {
                self.Mymessages = Mymessages!
                self.tableView.reloadData()
            }
        }
    }

func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
    return Mymessages.count
        
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageViewCell") as! MessageViewCell
        let message = Mymessages[indexPath.row]
        let name = message["Writer"] as! PFUser
          cell.nameText.text = name.username
          cell.messageText.text = message["TheMessages"] as! String
        
        return cell
        }

        /*
        // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
        }
        */
        
    @IBAction func BackButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
}
