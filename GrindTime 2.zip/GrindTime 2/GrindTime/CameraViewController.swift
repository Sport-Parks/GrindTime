//
//  CameraViewController.swift
//  GrindTime
//
//  Created by user191262 on 4/11/21.
//

import UIKit
import Parse
import AlamofireImage

class CameraViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var image: UIImageView!
    
    
    @IBOutlet weak var comment: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func tapbutton(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            picker.sourceType = .camera
        }else {
            picker.sourceType = .photoLibrary
        }
            present(picker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let Image = info [.editedImage] as! UIImage
        let size = CGSize(width: 700, height: 700)
        let scaledImage = Image.af_imageScaled(to: size)
        image.image = scaledImage
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func commentbutton(_ sender: Any) {
        let comments = PFObject(className: "UserComments")
            
            comments["Comments"] = comment.text!
            comments["Writer"] = PFUser.current()!
            let imageData = image.image!.pngData()
            let file = PFFileObject(name: "image.png", data: imageData!)
            comments["Pic"] = file
            
            comments.saveInBackground { (success, error) in
                if success {
                    self.dismiss(animated: true, completion: nil)
                    print("Saved!")
                } else {
                    print("There is an error! Try again!")
                }
            }
        }    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

