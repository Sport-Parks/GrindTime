//
//  MessageCameraViewController.swift
//  GrindTime
//
//  Created by user191262 on 4/18/21.
//

import UIKit
import Parse
import AlamofireImage

class MessageCameraViewController: UIViewController{


    @IBOutlet weak var textviewField: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func sendButton(_ sender: Any) {
        let messages = PFObject(className: "Messages")
            
            messages["TheMessages"] = textviewField.text!
            messages["Writer"] = PFUser.current()!
            
            messages.saveInBackground { (success, error) in
                if success {
                    self.dismiss(animated: true, completion: nil)
                    print("Saved!")
                } else {
                    print("There is an error! Try again!")
                }
            }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
