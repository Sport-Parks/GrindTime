//
//  ReplysecondViewController.swift
//  GrindTime
//
//  
//

import UIKit
import Parse
import AlamofireImage

class ReplysecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    
    @IBOutlet var tableView: UITableView!

    var Myreply = [PFObject]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
       let Query = PFQuery(className: "replys")
       Query.includeKey("user")
       Query.limit = 50
        
        Query.findObjectsInBackground { (Myreply, error) in
            if Myreply != nil {
                self.Myreply = Myreply!
                self.tableView.reloadData()
           }
    }
}
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           
           return Myreply.count
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let Cell = tableView.dequeueReusableCell(withIdentifier: "ReplyViewCell") as! ReplyViewCell
        let Reply = Myreply[indexPath.row]
        let users = Reply["user"] as! PFUser
        Cell.ReplyName.text = users.username
        Cell.replyLabel.text = Reply["thereply"] as! String
           
        return Cell
    }    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func backButton(_ sender: Any) {
        dismiss(animated: true, completion: nil)    }
}
