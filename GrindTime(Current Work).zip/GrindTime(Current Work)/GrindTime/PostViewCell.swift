//
//  PostViewCell.swift
//  GrindTime
//
//  Created by GrindTime Team
//


import UIKit
import Parse

class PostViewCell: UITableViewCell {

    @IBOutlet weak var nameField: UILabel!
    
    @IBOutlet weak var commentLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
