//
//  LoginViewController.swift
//  GrindTime
//
//  Created by GrindTime Team.
//

import UIKit
import Parse

class LoginViewController: UIViewController {

    @IBOutlet weak var loginusernamefield: UITextField!
    
    @IBOutlet weak var loginpasswordfield: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Onlogin(_ sender: Any) {
        
        let username = loginusernamefield.text!
        let password = loginpasswordfield.text!
        
        PFUser.logInWithUsername(inBackground: username, password: password) { (user, error) in
            if user != nil {
                self.performSegue(withIdentifier: "HomepageSegue", sender: nil)
            }else{
                print("Error: \(error?.localizedDescription)")
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
