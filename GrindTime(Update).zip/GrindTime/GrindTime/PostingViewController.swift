//
//  PostingViewController.swift
//  GrindTime
//
//  Created by GrindTime Team

//

import UIKit
import Parse

class PostingViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    
    @IBOutlet weak var tableView: UITableView!
    
    var comment = [PFObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let query = PFQuery(className:"Comment")
        query.includeKeys(["Users", "Comment"])
        query.limit = 20
        
        query.findObjectsInBackground { (comment, error) in
            if comment != nil {
                self.comment = comment!
                self.tableView.reloadData()
            }
            
        }
    }
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return comment.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostViewCell") as! PostViewCell
        let Mycomments = comment[indexPath.row]
        let name = Mycomments["Users"] as! PFUser
        cell.nameField.text = name.username
        
        cell.commentLabel.text = Mycomments["Comment"] as? String
        
        return cell
        
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func Backbutton(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
    }
}
